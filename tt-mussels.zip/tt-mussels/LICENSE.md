***Note of the author***

THIS IS A TRIAL FONT FOR PERSONAL USE ONLY. If you want to use the font in published or commercial projects you will have to buy it:   
 <https://typetype.org/fonts/tt-mussels/>  
   
 ---  
   
 More TypeType fonts and trials: <https://typetype.org/fonts>  
 More about licensing: <https://typetype.org/licensing>  
 Contact us: <commercial@typetype.org>  
   
 We're on social media:  
 instagram.com/typetype.foundry  
 behance.net/typetype  
 twitter.com/_TYPETYPE_